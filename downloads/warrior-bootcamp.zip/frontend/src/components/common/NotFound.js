//rfc
import React from "react";

export default () => {
  return (
    <div>
      <h1 className="display-4">Página não encontrada</h1>
      <p>Desculpe, a página solicitada não existe :|</p>
    </div>
  );
};
